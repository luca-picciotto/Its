export interface Pizza{
    nome: string;
    prezzo: number;
    ingredienti: string[];
    img: string;
}