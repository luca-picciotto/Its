import { Component } from "@angular/core";

@Component({
    selector: "app-primo",
    //todo è solo una string ache vve nell'html, può essere chiamato come si vuole (es. selector: "gigi-finizio")
    standalone: true,
    imports: [],
    templateUrl: "./primo-component.component.html",
    styleUrl: "./primo-component.component.css"
})
export class PrimoComponentComponent{

}