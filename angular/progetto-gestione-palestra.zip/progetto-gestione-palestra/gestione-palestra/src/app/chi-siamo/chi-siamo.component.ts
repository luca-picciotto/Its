import { Component } from '@angular/core';

@Component({
  selector: 'app-chi-siamo',
  standalone: true,
  imports: [],
  templateUrl: './chi-siamo.component.html',
  styleUrl: './chi-siamo.component.css'
})
export class ChiSiamoComponent {

}
