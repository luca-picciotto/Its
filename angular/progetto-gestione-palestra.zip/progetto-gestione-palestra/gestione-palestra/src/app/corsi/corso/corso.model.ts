export interface Corso {
    id: string ;
    nome: string;
    descrizione: string;
    istruttore: string;
    durata: number;
    capacitaMassima: number;
    iscritti: number;
}


export default Corso;