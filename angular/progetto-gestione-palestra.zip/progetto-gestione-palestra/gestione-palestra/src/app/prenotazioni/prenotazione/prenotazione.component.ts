import { Component } from '@angular/core';

@Component({
  selector: 'app-prenotazione',
  standalone: true,
  imports: [],
  templateUrl: './prenotazione.component.html',
  styleUrl: './prenotazione.component.css'
})
export class PrenotazioneComponent {

}
