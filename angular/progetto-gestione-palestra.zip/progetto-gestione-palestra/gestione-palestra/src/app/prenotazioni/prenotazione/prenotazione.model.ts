export interface Prenotazioni {
    id: number,
    idCorso: string
}

export default Prenotazioni;