import { Component } from '@angular/core';

@Component({
  selector: 'app-prenotazioni',
  standalone: true,
  imports: [],
  templateUrl: './prenotazioni.component.html',
  styleUrl: './prenotazioni.component.css'
})
export class PrenotazioniComponent {

}
