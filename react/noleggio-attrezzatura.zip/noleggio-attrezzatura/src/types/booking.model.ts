interface BookingModel {
    id: number | null;
    equipment_id: number | null;
    start_date: string | null;
    end_date: string | null;
    
}

export default BookingModel;