export interface EquipmentBookingRequest {
	duration: number;
}

export default EquipmentBookingRequest;