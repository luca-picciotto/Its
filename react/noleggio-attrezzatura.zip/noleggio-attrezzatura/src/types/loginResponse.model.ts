export interface LoginResponse {
    token: string | '';
}

export default LoginResponse;   