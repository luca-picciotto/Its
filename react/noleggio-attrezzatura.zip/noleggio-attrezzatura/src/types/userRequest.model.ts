export interface UserRequest {
	username: string;
	password: string;
}

export default UserRequest;